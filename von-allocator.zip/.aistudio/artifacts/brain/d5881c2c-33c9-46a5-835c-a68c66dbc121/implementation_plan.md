# Minimalist UX, Mobile To Buy, Clickable Sidebar & 2-Column Debt Schedule Revision Plan

This revision refines three core areas of Von Allocator—the **To Buy** workspace, the **Desktop Sidebar**, and the **Priority Debts** screen—to eliminate mobile text overlap, remove visual clutter through a minimalist single-elevation design system, ensure the To Buy page starts completely blank on new state generation, make the sidebar background directly clickable to collapse or expand, and convert Divided Weeks into a clean 2-column grid.

---

### User Review & Critical Decisions

> [!IMPORTANT] All clarifying preferences were confirmed prior to drafting this plan and directly govern the layout architecture below.

- **Confirmed Decision 1 (To Buy Minimalist Layout)**: The "Add To Buy Note" composer becomes a **collapsible Add Item panel** (collapsed by default on load), paired with minimalist task cards, single-row mobile-safe category headers, and touch/pointer cross-list drag-and-drop.
- **Confirmed Decision 2 (Clickable Sidebar Toggle)**: Clicking anywhere on the **desktop sidebar background** (outside navigation links, action buttons, or form controls) toggles between collapsed (`76px`) and expanded (`240px`) states in both directions.
- **Confirmed Decision 3 (Debt Page & 2-Column Weeks)**: The "Add Debt in Advance" form becomes a **collapsible top panel** above a wider **2-column SPaylater and SLoan grid**, with every bill's **Divided Weeks** schedule rendered in a **2-column grid** of minimalist week tiles.
- **Confirmed Decision 4 (Blank To Buy Default)**: Newly generated or fresh application states initialize with zero To Buy items and zero pre-seeded categories, syncing bidirectionally with Firebase Live.

---

### 1. Overview & Core Concept

- **What It Does**: Streamlines daily mobile and desktop money management across Von Allocator by decluttering dense forms into on-demand collapsible drawers, giving checklist and debt data room to breathe, and enabling instant one-click sidebar toggling.
- **Target Audience / Persona**: Mobile-first and desktop personal budgeters tracking weekly allocations, Shopee debt installments, and planned purchases synced live via Firebase.
- **Key Value**: Zero overlapping text on narrow mobile screens (~360px–414px), faster debt scanning with 2-column Divided Weeks, a distraction-free zero-state To Buy workspace, and effortless workspace resizing via the clickable sidebar.

---

### 2. User Experience & Visual Design

#### Key User Flows

1. **To Buy Workspace (Zero-State & Mobile Flow)**:
   - On a fresh load, the To Buy view displays an understated summary strip, an empty category creator bar (`New Category`), and a clean empty-state prompt with quick triggers to create a category or open the collapsible **Add Item** panel.
   - Tapping **+ Add Item** reveals the minimalist item composer (`Title`, `Category`, `Price`, `Bank`, optional `Shop/Link`, `Deadline`, `Note`, and `Fixed Expenses` sync toggle). Submitting collapses or resets cleanly while syncing immediately to Firebase Live.
   - Users drag tasks horizontally/vertically via the grip handle across category panels or drag category headers to reorder lists, with clean drop-target highlights and zero overflowing badges.
2. **Clickable Sidebar Toggle (Desktop)**:
   - Moving to the sidebar's open background surface shows a subtle pointer cue. Clicking empty rail space collapses the 240px rail into a slim icon-only dock; clicking the collapsed rail background again expands it back smoothly without accidentally triggering nav switches.
3. **Priority Debts (2-Column Workspace & 2-Column Weeks)**:
   - Opening the Debts page presents the concise summary bar with a **+ Add Debt** button above a wide two-column layout dedicated to **SPaylater** (left) and **SLoan** (right).
   - Expanding a bill card shows its **Divided Weeks** arranged in compact **2-column tiles** (`grid-cols-2`), each displaying week number, date range, peso amount, and a clean single-line `Paid` / `Pay` toggle synced with Saved & QRPh.

#### Visual Identity & Theme

- **Aesthetic Direction**: Calm, disciplined financial utility—minimalist flat surfaces separated by crisp 1px hairline borders and generous whitespace rather than heavy nested box sandwiches or pill clutter.
- **Color Palette & Mood (60-30-10)**:
  - *60% Neutral Canvas*: Existing `--bg-canvas` (`#0b0f17` dark / `#f4f6fa` light).
  - *30% Structural Surfaces*: Flat `--bg-surface` (`#131823` / `#ffffff`) and subtle hairline `--border-subtle` (`#1f2737` / `#e5e9f0`), removing thick `border-l-4` accent stripes on Debt overview headers.
  - *10% Semantic Accents*: Primary blue (`#2563eb`) reserved strictly for primary CTAs and active filter tabs; green (`#16a34a` / `#10b981`) for paid/synced states; amber (`#d97706`) for upcoming due amounts; crimson (`#dc2626`) for deficits/destructive confirms.
- **Typography & Hierarchy**: Preserves the existing **Montserrat** display headings (`font-bold`, balanced line wrapping) paired with **Poppins** body copy and strict `tabular-nums` (`.mono-num`) alignment on all peso figures, counters, and week amounts.
- **Component Styling & Anti-Clutter Rules**:
  - *Unboxed Metadata*: Replace pill-badge stacks on To Buy cards and Debt cards with quiet inline text separated by middots (`·`), reserving rounded pills strictly for interactive buttons, filter tabs, and bank identifiers where needed.
  - *Responsive Overflow Containment*: Apply `min-w-0`, `flex-wrap`, and `whitespace-nowrap shrink-0` on action buttons, ensuring long titles, URLs, and category names wrap or truncate cleanly without overlapping adjacent controls on mobile viewports.

#### Interactive Feedback & Motion

- Smooth ≤200ms height/opacity reveal for collapsible Add Item and Add Debt panels.
- Crisp drop-line indicators (`drag-over-top`, `drag-over-bottom`, `task-drop-active`) during both desktop pointer drag and mobile touch handle drag.
- Inline two-step "Delete All" confirmation button avoiding disruptive browser dialogs, plus instant non-blocking toast confirmations after Firebase Live syncs.

---

### 3. Key Product Decisions & Trade-Offs

- **Decision 1 — Collapsible Composers Above Lists vs. Permanent Left Sidebar Forms**:
  - *Chosen Approach*: Hide both the To Buy Add Form and Debt Add Form behind clean toggle headers by default, placing lists in full width below.
  - *Why*: Eliminates vertical scroll fatigue on mobile where forms used to push actual items below the fold, and unlocks wide 2-column provider panels on Debt desktop screens so 2-column Divided Weeks fit comfortably without crowding.
  - *Alternatives Considered*: Keeping permanent 3-column layouts on desktop or modal popups; collapsible panels preserve in-context visibility when editing while defaulting to a clean view.
- **Decision 2 — Truly Blank To Buy Default Without Forced Fallbacks**:
  - *Chosen Approach*: Initialize `DEFAULT_TOBUY_CATEGORIES = []` and `toBuyItems = []`, and let normalized states remain empty unless the user explicitly adds items or categories or pulls existing ones from Firebase Live.
  - *Why*: Matches the requirement for a clean zero-state page with no pre-filled sample categories or tasks, while seamlessly preserving user-created categories stored remotely in Firestore.
  - *Alternatives Considered*: Forcing an auto-created `General` category on empty state, which conflicts with the blank initial view.
- **Decision 3 — Background Click Detection on Desktop Sidebar**:
  - *Chosen Approach*: Allow `handleSidebarContainerClick` to toggle collapse/expand whenever an interactive child (`button`, `a`, `input`, `select`, nav tab) is not the click target.
  - *Why*: Lets the entire unused surface of the sidebar rail act as a tactile expand/collapse toggle in both states while preventing accidental toggles when navigating or clicking account actions.
  - *Alternatives Considered*: Restricting toggle strictly to the small corner icon button, which is harder to hit rapidly.

---

### 4. Technical Architecture & Data Strategy *(Technical Reference)*

#### Architecture & Component Diagram

```text
┌──────────────────────────────────────────────────────────────────────┐
│                        Von Allocator App Shell                       │
│  ┌───────────────────────┐   ┌────────────────────────────────────┐  │
│  │ Desktop Sidebar Rail  │   │ Main Content Viewport              │  │
│  │ · Bg Click -> Toggle  │   │                                    │  │
│  │ · Collapse/Expand btn │   │  ┌──────────────────────────────┐  │  │
│  └───────────────────────┘   │  │ Page: Debts                  │  │  │
│                              │  │ · Summary Strip (+Add btn)   │  │  │
│                              │  │ · [Collapsible Add Debt]     │  │  │
│                              │  │ · Grid (SPaylater │ SLoan)   │  │  │
│                              │  │   └─ 2-Col Divided Weeks     │  │  │
│                              │  └──────────────────────────────┘  │  │
│                              │  ┌──────────────────────────────┐  │  │
│                              │  │ Page: To Buy (Blank Default) │  │  │
│                              │  │ · Minimal Header (+Add btn)  │  │  │
│                              │  │ · [Collapsible Add Note]     │  │  │
│                              │  │ · Inline New Category Bar    │  │  │
│                              │  │ · Category Dropzones / DnD   │  │  │
│                              │  └──────────────────────────────┘  │  │
│                              └────────────────────────────────────┘  │
└──────────────────────────────────┬───────────────────────────────────┘
                                   │ Two-Way Real-Time Sync
                                   ▼
                 ┌───────────────────────────────────┐
                 │ Firebase Live (Firestore State)   │
                 │ · toBuyCategories (default [])    │
                 │ · toBuyItems (default [])         │
                 │ · debts + paidWeeks               │
                 └───────────────────────────────────┘
```

#### Data Model & State

- **`appState.toBuyCategories`**: Array of `{ id, name, color, collapsed }`, initialized as `[]`. Normalization preserves valid remote arrays verbatim and assigns orphaned items cleanly to `'uncategorized'` only when items exist without categories.
- **`appState.toBuyItems`**: Array of `{ id, categoryId, title, price, shopOrLink, deadline, bank, note, checked, syncedToFixed, fixedItemId, createdAt }`, initialized as `[]`.
- **UI Toggle States (Ephemeral Client UI Flags)**:
  - `isToBuyAddPanelOpen` (`false` by default): Controls visibility of the To Buy Add Item drawer, toggled via the header button or category `+` quick-add action.
  - `isDebtAddPanelOpen` (`false` by default): Controls visibility of the Add Debt in Advance panel.
  - `sidebar[data-collapsed]`: Synchronized by `setSidebarCollapsed(bool)` and toggled cleanly from either the header button or sidebar background clicks.

#### Interactive Component & State Mapping

- **Sidebar Background Toggle**: `handleSidebarContainerClick(event)` filters out clicks originating on `button, a, input, select, textarea, label, [role="button"]`, calling `toggleSidebar()` on empty rail background clicks so both expand and collapse transitions work reliably.
- **To Buy Mobile & Minimalist Engine**:
  - `toggleToBuyAddPanel(forceOpen?)`: Opens/closes the Add Item panel smoothly; clicking `+` on any category opens the panel and pre-selects that category without cramped inline forms.
  - `buildToBuyTaskCardHTML()` & `renderToBuyPage()`: Refactors mobile header, category header controls, and task rows with flex truncation (`min-w-0 flex-1`), compact icon actions, and unboxed `·` metadata so cards never collide horizontally at 360px+.
  - Cross-List HTML5 & Touch DnD handlers remain bound to the refactored minimalist cards and category containers, persisting reorders immediately to Firebase Live via `persistUserData(true)`.
- **Debt 2-Column Schedule & Minimalist Layout**:
  - `toggleDebtAddPanel(forceOpen?)`: Expands/collapses the top debt composer while preserving live weekly preview math (`updateNewDebtPreview`).
  - `buildDividedWeeksScheduleHTML()`: Renders installment week tiles inside a responsive `grid grid-cols-2 gap-1.5 sm:gap-2` container with compact week label, date range, tabular peso share, and interactive Paid button synced bidirectionally with Saved & QRPh.
